该版本改编自DesertsP 的 [Valine-Admin](https://github.com/DesertsP/Valine-Admin) ，增加了Server酱推送功能。

## 注意！与 zhaojun1998 改编的 Valine-Admin 不同！
### 不通用，否则会导致无法进入后台界面

#### 如需要 zhaojun1998 版本、且支持微信推送功能的版本，请至 [Valine-Admin-Server](https://github.com/sviptzk/Valine-Admin-Server/) 
* 注：该版本与你现在所看到的这个改变版无关

配置方法：[为博客的Valine评论添加邮件与微信双提醒]()